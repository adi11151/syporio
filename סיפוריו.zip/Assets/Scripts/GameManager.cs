﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
//using System.EventArgs;
using System;
using UnityEngine.SceneManagement;


public class GameManager : MonoBehaviour {
    


    private float points = 0;

    [SerializeField, Tooltip("Level Loader instance")]
    private LevelLoader _levelLoader;
    private Enemy _enemyInstance;
    private Player _syporioInstance;
    private  GameObject[] _copSpawns;

    [SerializeField, Tooltip ("Camera with a camera controller")]
    private CameraController _cameraController;

    [SerializeField, Tooltip("Minimum y position for player. Below this line, he will die")]
    private float _lowDeathLine;

    // Use this for initialization
    void Start () {
        _copSpawns = GameObject.FindGameObjectsWithTag("CopSpawnPos");
        _syporioInstance = _levelLoader.SpawnSyporio();
        _syporioInstance.Died += PlayerDead;

        _cameraController.Setup(_syporioInstance.gameObject);

        _enemyInstance  = _levelLoader.SpawnCop(_copSpawns[0].transform);
        _enemyInstance.EnemyDead += EnemyDead;
    }


    /// <summary>
    /// Enemy is dead
    /// </summary>
    /// <param name="posx">current x position .</param>
    /// <param name="posy">current y position.</param>
    public void EnemyDead(float posx, float posy){
        Debug.Log (posx + "  " + posy);
        _enemyInstance.EnemyDead -= EnemyDead;
        Debug.Log("Dead");
        var drop = _levelLoader.SpawnDrop (posx, posy);
        drop.GameManager = this;
    }


   /// <summary>
   /// adding point when player took a drop
   /// </summary>
    public void AddPoint(){
        points++;
        Debug.Log ("point+1");
    }

    /// <summary>
    /// when syporio is dead
    /// </summary>
    public void PlayerDead(){
        Debug.Log ("syporio is dead");
        _syporioInstance.Died -= PlayerDead;
        GameOver ();
    }

    /// <summary>
    /// Games is over.
    /// </summary>
    public void GameOver(){
        SceneManager.LoadScene(0);
    }


    /// <summary>
    /// Update function checking each frame if syporio died
    /// </summary>
    void Update()
    {
        CheckPlayerDeath();
    }

    public void CreateCloud(){
        _levelLoader.SpawnCloud();
    }

    /// <summary>
    /// Checks the player death by checking if it reached to minimum point.
    /// </summary>
    private void CheckPlayerDeath()
    {
        if (_syporioInstance.transform.position.y < _lowDeathLine)
            _syporioInstance.Die();
    }

    /// <summary>
    /// draw gizmos at the minimum position.
    /// </summary>
    public void OnDrawGizmos()
    {
        Vector3 from = new Vector3(-100f, _lowDeathLine, 0f);
        Vector3 to = new Vector3(100f, _lowDeathLine, 0f);
        Gizmos.color = Color.yellow;
        Gizmos.DrawLine(from, to);
    }
}
