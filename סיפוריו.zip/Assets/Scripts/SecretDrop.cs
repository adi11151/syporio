﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SecretDrop : Collectible {
    public override void Collect()
    {
        GameManager.AddPoint();
        GameManager.CreateCloud();
        Debug.Log("Took secret drop");
    }
}
