﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LevelLoader : MonoBehaviour {
    [SerializeField]
    private GameObject Syporio;
    [SerializeField]
    private GameObject Cop;
    [SerializeField]
    private GameObject Drop;
    [SerializeField]
    private GameObject Cloud;

    [SerializeField, Tooltip("Starting position for syporio")]
    private Transform _startPos;
    private Player _SyporioInstance;

    public Player SpawnSyporio(){
        Debug.Log("spawnSyporio");
        var syporioObject = Instantiate(Syporio, _startPos.position, Quaternion.identity);
        _SyporioInstance = syporioObject.GetComponent<Player>();
        return _SyporioInstance;
    }

    public Enemy SpawnCop(Transform SpawnPos){
        var enemyObject = Instantiate(Cop, SpawnPos.position, Quaternion.identity);
        Enemy _EnemyInstance = enemyObject.GetComponent<Enemy>();
        _EnemyInstance.setTarget(_SyporioInstance.transform);
        return _EnemyInstance;
    }


    public Drop SpawnDrop(float x, float y)
    {
        Vector2 pos = new Vector2(x, y + 1f);
        Debug.Log(x + "  " + y);
        Debug.Log("Spawn" + pos);
        var newDrop = Instantiate(Drop, pos, Quaternion.identity);
        return newDrop.GetComponent<Drop>();
    }

    public void SpawnCloud()
    {
        var cloudObj = Instantiate(Cloud, Cloud.transform.position, Quaternion.identity);
        Debug.Log("instan");

    }



}
