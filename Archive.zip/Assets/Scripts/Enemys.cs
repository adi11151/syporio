﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

public class Enemys : MonoBehaviour {
	
	public Transform followTarget;
	private Rigidbody2D enemy;
	public bool isLeft = true;
	Collider collider;
	public event Action<float, float> EnemyDead;
//	public delegate void EnemyDead(Enemys m, float e);


	float speed = 10;
	// Use this for initialization
	void Start () {
//		syporio = GameObject.FindGameObjectWithTag ("Player").transform;
		enemy = gameObject.GetComponent<Rigidbody2D> () ;

		collider = GetComponent<Collider>();
	}

	public void setTarget(Transform target){
		followTarget = target;
	}

	public void Die(){
		float posx = transform.position.x;
		float posy = transform.position.y;
		transform.localScale = new Vector3(transform.localScale.x, 0.1f,transform.localScale.z );
		Debug.Log (posx + "  " + posy);
		if (EnemyDead != null) {
			Debug.Log (posx + "  " + posy);
			EnemyDead (posx, posy);
		}
		Destroy (this.gameObject, 0.2f);
	}


	// Update is called once per frame
	void Update () {
		Vector2 targetHeading = followTarget.transform.position - transform.position;
		Vector2 targetDirection = targetHeading.normalized;
		Vector2 scale = transform.localScale;
		if (targetHeading.x > 0.0f && isLeft == true) {
			scale.x *= -1;
			isLeft = !isLeft;
		}else if (targetHeading.x < 0.0f && isLeft == false){
			scale.x *= -1;
			isLeft = !isLeft;
		}
//		Debug.Log ("scale " + transform.localScale);
		transform.localScale = scale;
//		Debug.Log ("scale " + transform.localScale);
//		transform.eulerAngles = new Vector3(0, transform.eulerAngles.y * targetDirection , 0);

		//move towards the player
		enemy.velocity = new Vector2 (targetDirection.x * 1.5f, enemy.velocity.y);
	}
}
