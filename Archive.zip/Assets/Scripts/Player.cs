﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

 
public class Player: MonoBehaviour {

	// Use this for initialization
//	Controller2D controller;
	public int playerSpeed = 10;
	public bool isRight = true;
	public float jumpPower ;
	public float moveX, moveY;
	private Rigidbody2D player;
	private float speed = 20f;
	public bool grounded = false;
	public bool jumping = false;
	public bool onAir = false;
	public float time = 0;
	public event Action playerStatus;
	public event Action tookDrop;
	public event Action tookSecretDrop;


	void Start () {
		player = gameObject.GetComponent<Rigidbody2D> () ;


	}

	// Update is called once per frame
	void Update () {
//		Debug.Log ("transform.localScale" + transform.localScale);
		move ();
		jump ();
		if (transform.position.y < -20)
			OnPlayerDead ();
	}

	void OnCollisionEnter2D(Collision2D collision){
		if (collision.gameObject.tag == "Enemy") {
			ContactPoint2D contact = collision.contacts [0];
//			Vector2 pos = collision.contacts[0];
//			Debug.Log ("enemy"+ contact.point.x +" "+ contact.point.y+ " "+ transform.position.x+" "+transform.position.y);
			if (contact.point.y < transform.position.y) {
				Debug.Log ("enemy dead");
				Enemys enemyScript = collision.gameObject.GetComponent<Enemys> ();
				enemyScript.Die ();

			} else {
				Debug.Log ("playerDead");
				OnPlayerDead ();
			
			}
		} 
		if (collision.gameObject.tag == "Drop") {
			Destroy (collision.collider.gameObject);
			tookDrop ();
		}
		if(collision.gameObject.tag == "secretDrop"){
			Debug.Log ("instan1");
			Destroy (collision.collider.gameObject);
			tookSecretDrop ();
		}
	}

	void FixedUpdate(){
		if (jumping) {
			player.AddForce(Vector2.up * 200);
		}

	}

	void jump(){
		if (Input.GetKey (KeyCode.Space) && time < 0.15f) {
			jumping = true;
			time += Time.deltaTime;

		} else
			jumping = false;
		if (player.velocity.y == 0) {
			time = 0;
		}
	}

	void move(){
		moveX = Input.GetAxis("Horizontal");
		if (moveX < 0.0f && isRight == false) {
			flipPlayer ();
			Debug.Log ("pressed");
		} else if (moveX > 0.0f && isRight == true) {
			flipPlayer ();
		}
		player.velocity = new Vector2 (moveX * speed, player.velocity.y);
	}


	void flipPlayer(){
		isRight = !isRight;
		Vector2 scale = transform.localScale;
		scale.x *= -1;
		transform.localScale = scale;

	}


	protected virtual void OnPlayerDead(){
		if (playerStatus != null) {
			playerStatus ();
		}
	}
}

