﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
//using System.EventArgs;
using System;
using UnityEngine.SceneManagement;


public class GameManager : MonoBehaviour {
    

    public GameObject Drop;

    public GameObject Cloud;
    private float points = 0;
    private LevelLoader levelLoader;
    private Enemy _EnemyInstance;
    private Player _SyporioInstance;
    private  GameObject[] copSpawns;




    // Use this for initialization
    void Start () {
        levelLoader = new LevelLoader();
        copSpawns = GameObject.FindGameObjectsWithTag("CopSpawnPos");
        _SyporioInstance = levelLoader.SpawnSyporio();
        _SyporioInstance.playerStatus += PlayerDead;

        var enemyObject  = levelLoader.SpawnCop(copSpawns[0].transform);
        _EnemyInstance.EnemyDead += EnemyDead;

        _SyporioInstance.tookSecretDrop += SecretDrop; 
    }


    /// <summary>
    /// Enemy is dead
    /// </summary>
    /// <param name="posx">current x position .</param>
    /// <param name="posy">current y position.</param>
    public void EnemyDead(float posx, float posy){
        Debug.Log (posx + "  " + posy);
        _EnemyInstance.EnemyDead -= EnemyDead;
        Debug.Log("Dead");
        levelLoader.SpawnDrop (posx, posy);
        _SyporioInstance.tookDrop += CountPoints;
    }



    public void SecretDrop(){
        points++;
        var cloudObj = Instantiate (Cloud, Cloud.transform.position, Quaternion.identity);
        Debug.Log ("instan");

    }
   
    public void CountPoints(){
        points++;
        Debug.Log ("point+1");
    }

    public void PlayerDead(){
        Debug.Log ("syporio is dead");
        _SyporioInstance.playerStatus -= PlayerDead;
        GameOver ();
    }

    public void GameOver(){
        Time.timeScale = 0;
        Retry ();
    }

    public void Retry(){
        Debug.Log ("yesQ!");
        foreach (GameObject o in GameObject.FindObjectsOfType<GameObject>()) {
            Destroy (o);
        }
        Time.timeScale = 1;
    }
    
    // Update is called once per frame


}
