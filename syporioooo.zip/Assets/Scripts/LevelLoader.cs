﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LevelLoader : MonoBehaviour {
    public GameObject Syporio;
    public GameObject Cop;
    public GameObject Drop;

    public GameObject _startPos;
    private Player _SyporioInstance;

    public Player SpawnSyporio(){
        Debug.Log("spawnSyporio");
        Vector2 vec = new Vector2(3f, 0f);
        var syporioObject = Instantiate(Syporio, vec, Quaternion.identity);
        _SyporioInstance = syporioObject.GetComponent<Player>();
        return _SyporioInstance;
    }

    public Enemy SpawnCop(Transform SpawnPos){
        var enemyObject = Instantiate(Cop, SpawnPos.position, Quaternion.identity);
        Enemy _EnemyInstance = enemyObject.GetComponent<Enemy>();
        _EnemyInstance.setTarget(_SyporioInstance.transform);
        return _EnemyInstance;
    }


    public void SpawnDrop(float x, float y)
    {
        Vector2 pos = new Vector2(x, y + 1f);
        Debug.Log(x + "  " + y);
        Debug.Log("Spawn" + pos);
        var newDrop = Instantiate(Drop, pos, Quaternion.identity);
    }


}
