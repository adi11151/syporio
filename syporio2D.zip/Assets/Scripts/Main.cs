﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
//using System.EventArgs;
using System;
using UnityEngine.SceneManagement;


public class Main : MonoBehaviour {
	
	public GameObject syporio;
	public GameObject cop;
	public GameObject drop;
	private Vector2 startPos = new Vector2 (0f,0f);
	Player syporioScript; 
	float xMin = -2f;
	float xMax = 100f;
	float yMin = -20f;
	float yMax = 2.5f;
	public GameObject canvas;
	public GameObject button;
	public GameObject cloud;
	private float points = 0;
	Enemys enemyScript;

	// Use this for initialization
	void Start () {
		var syporioObject = Instantiate (syporio, startPos, Quaternion.identity);
		syporioScript = syporioObject.GetComponent<Player> ();
		syporioScript.playerStatus += PlayerDead;
		Vector2 enemyStartPos = new Vector2 (15f, -2f);
		var enemyObject = Instantiate (cop, enemyStartPos , Quaternion.identity);
		enemyScript = enemyObject.GetComponent<Enemys> ();
		enemyScript.setTarget (syporioScript.transform);
		enemyScript.EnemyDead += EnemyDead;
		syporioScript.tookSecretDrop += secretDrop; 
	}

	public void EnemyDead(float posx, float posy){
		Debug.Log (posx + "  " + posy);
		enemyScript.EnemyDead -= EnemyDead;
		Debug.Log("Dead");
		SpawnDrop (posx, posy);
	}

	public void secretDrop(){
		points++;
		var cloudObj = Instantiate (cloud, cloud.transform.position, Quaternion.identity);
		Debug.Log ("instan");

	}

	public void countPoints(){
		points++;
		Debug.Log ("point+1");
	}

	public void PlayerDead(){
		Debug.Log ("syporio is dead");
		syporioScript.playerStatus -= PlayerDead;
		gameOver ();
	}

	public void SpawnDrop(float x, float y){
		
		Vector2 pos = new Vector2 (x, y+1f);
		Debug.Log (x + "  " + y);
		Debug.Log("Spawn" + pos);
		syporioScript.tookDrop += countPoints;
		var newDrop = Instantiate (drop, pos, Quaternion.identity);	

	}

	public void gameOver(){
		Time.timeScale = 0;
		Retry ();
	}

	public void Retry(){
		Debug.Log ("yesQ!");
		foreach (GameObject o in GameObject.FindObjectsOfType<GameObject>()) {
			Destroy (o);
		}
		Time.timeScale = 1;
		UnityEngine.SceneManagement.SceneManager.LoadScene("SYP2D");


	}
	
	// Update is called once per frame
	void LateUpdate () {
		float x = Mathf.Clamp (syporioScript.transform.position.x+2, xMin, xMax);
		float y = Mathf.Clamp (syporioScript.transform.position.y, yMin, yMax);
		gameObject.transform.position = new Vector3 (x, y, gameObject.transform.position.z);

	}
}
